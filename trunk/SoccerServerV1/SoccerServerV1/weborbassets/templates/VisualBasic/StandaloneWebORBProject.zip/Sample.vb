
Module Sample

    Sub Main()

    End Sub

End Module