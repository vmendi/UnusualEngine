
Public Class Sample
    Public Sub New()
        '
    End Sub

    Public Function ClassLibraryEcho(text as String)
        Return "Gateway echo: " & text
    End Function
End Class