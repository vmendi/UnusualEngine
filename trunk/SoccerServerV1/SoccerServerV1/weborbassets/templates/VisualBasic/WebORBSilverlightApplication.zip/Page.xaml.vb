Imports Weborb.Client

Partial Public Class Page
    Inherits UserControl

    Private proxy As WeborbClient

    Public Sub New()
        InitializeComponent()
        
        proxy = New WeborbClient(App.WeborbURL, Me)

        ' a sample invocation would look like this:
        'Dim responder As Responder(Of Foo) = New Responder(Of Foo)(AddressOf GotFoo, AddressOf GotError)
        'proxy.Invoke("com.foo.FooService", "getFoo", Nothing, responder)        
    End Sub


    ' sample responder for getFoo invocation:
    'Public Sub GotFoo(ByVal fooObject As Foo)
    ' we got foo from Java
    'End Sub

    ' sample error handler
    'Public Sub GotError(ByVal faultObject As Fault)
    ' faultObject contains Message and Detail properties
    'End Sub

End Class