using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
	/// <summary>
	/// Command prompt project with Standalone WebORB Messaging server
	/// </summary>
	public class Sample
	{
		public Sample()
		{
		}

		static void Main(string[] args)
        	{

		}

        }	
}
