using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
	/// <summary>
	/// Class library with WebORB
	/// </summary>
	public class Sample
	{
		public Sample()
		{
		}

		public string ClassLibraryEcho(string text)
		{
			return "Gateway echo: " + text;
		}
	}
}
